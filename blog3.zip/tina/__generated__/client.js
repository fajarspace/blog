import { createClient } from "tinacms/dist/client";
import { queries } from "./types";
export const client = createClient({ url: 'https://content.tinajs.io/1.4/content/cf7e7a3f-8276-4680-abb5-d61f6c5551be/github/master', token: '825fb31ba162ed2fd2f55dfba40aa4e97ed9c27b', queries });
export default client;
  