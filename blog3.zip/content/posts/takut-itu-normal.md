---
title: Takut itu normal
date: "2020-05-16T00:00:00.000Z"
description:
  Ketakutan dapat menghancurkan kita dengan dorongan yang membuat kita
  selalu membayangkan skenario terburuk akan segala sesuatu. Dan itu normal.
featured_image: https://i.ibb.co/6DP5bTR/silhouette-3777403-640.jpg
author: "Saya"
---

Ketakutan dapat menghancurkan kita dengan dorongan yang membuat kita selalu membayangkan skenario terburuk akan segala sesuatu.
Dan itu normal.
