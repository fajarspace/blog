---
description: "Kita lihat di internet banyak sekali lowongan pekerjaan, dari judul hingga persyaratan, perusahaan merekrut yang punya keahlian."
date: "2022-04-02T00:00:00.000Z"
featured_image: "https://i.ibb.co/yQMmmMf/pexels-cottonbro-3778179.jpg"
title: "Keahlian vs Attitude"
author: "Saya"
---

Kita lihat di internet banyak sekali lowongan pekerjaan, dari judul hingga persyaratan, perusahaan merekrut yang punya keahlian.

Logika nya bisa dipahami bahwa hanya satu dari sepuluh orang yang termasuk dalam 10% teratas dalam hal keahlian. Jika perusahaan membutuhkan orang-orang dengan keahlian, mereka harus membayar jauh lebih banyak dan bekerja jauh lebih keras untuk menemukan dan mempertahankan keahlian semacam itu.

Jadi kebanyakan perusahaan tidak mencoba. Mereka menciptakan pekerjaan yang dapat dilakukan dengan cukup baik oleh orang-orang dengan keahlian masing-masing.

Itu berarti bahwa pembeda sebenarnya di hampir setiap pekerjaan adalah Attitude. Dari tukang kayu hingga apoteker, seseorang dengan soft skill yang luar biasa (kejujuran, komitmen, kasih sayang, ketahanan, keikutsertaan, empati, kesediaan untuk dilatih) keterampilan nyata yang benar-benar kita inginkan.
