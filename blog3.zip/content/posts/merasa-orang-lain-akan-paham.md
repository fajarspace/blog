---
description: "Saat kita interaksi pasti terjadi komunikasi, bukan sekedar komunikasi, tapi komunikasi dengan jelas"
date: "2021-11-20T00:00:00.000Z"
featured_image: "https://i.ibb.co/JRsfTzC/telephone-3594206-640.jpg"
title: "Komunikasi dengan jelas"
author: "Saya"
---

Saat kita interaksi pasti terjadi komunikasi, bukan sekedar komunikasi, tapi komunikasi dengan jelas

Ketika pemerintah mengeluarkan aturan PPKM misalnya, tidak adanya edukasi untuk menjelaskan kenapa sebuah aturan PPKM diberlakukan, dan hasilnya kejadian dilapangan tidak sesuai, masyarakat tidak paham akibat tidak adanya edukasi yang jelas

Ketika orang berkomunikasi via digital. Baik itu sms/whatsapp. Di mana tidak ada intonasi ketika sedang mengetik. Tidak jelas, apakah orang lain dalam keadaan marah atau berbicara biasa. Akhirnya pihak lain akan mengasumsikan kalau lawan komunikasi nya sedang marah dan membalasnya dengan nada emosi

> Clear is kind  
> Unclear is unkind  
> \-Brene Brown

“Jelas itu baik, tidak jelas itu tidak baik”.

Saat kamu berbicara, sampaikan dengan jelas dan tenang, berikan konteks. Hindari asumsi
