---
description: "Terobsesi kepada kompetitor bukanlah mindset yang baik,"
date: "2022-05-06T00:00:00.000Z"
featured_image: "https://i.ibb.co/7J5vj1R/pexels-george-becker-131616.jpg"
title: "Mengabaikan kompetitor"
author: "Saya"
---

Terobsesi kepada kompetitor bukanlah mindset yang baik, Startup digital di masa sekarang sedang jaya Ratusan atau mungkin ribuan startup dibuat di berbagai daerah

Satu produk yang bertujuan sama, bisa jadi dikerjakan oleh puluhan startup lainnya. Orang-orang mulai mencari dana, untuk bisa memberi diskon lebih, untuk menarik perhatian pengguna

Kalau kamu sedang terjebak di permainan ini, Tidak ada cara lain selain, “menjadi lebih baik” dari kompetitor/pesaing kamu. Bukan lebih murah. Bermain lebih murah tidak akan ada habisnya

Bekerja lebih cerdas, bukan lebih keras
