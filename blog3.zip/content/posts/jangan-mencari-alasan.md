---
title: Jangan suka mencari alasan
date: "2020-05-12T00:00:00.000Z"
featured_image: https://i.ibb.co/Wp6jDy6/boys-1149665-640.jpg
description:
  mencari cari alasan itu sesuatu yg sering kita dengar dari orang lain,
  dari karyawan, murid, atau kita sebagai manusia, entah itu karena telat kerja/sekolah
  pasti selalu mencari cari alasan supaya terhindar dari hukuman/omelan.
author: "Saya"
---

“kok kamu telat mulu sih,?!”

“anu pak tadi macet dijalan”

“jangan alesan terus kamu,”

“saya tidak alesan pak”

“ya itu nama nya alesan, gimana sih”

mencari cari alasan itu sesuatu yg sering kita dengar dari orang lain, dari karyawan, murid, atau kita sebagai manusia, entah itu karena telat kerja/sekolah pasti selalu mencari cari alasan supaya terhindar dari hukuman/omelan. sadar gak sih , semakin kamu mencari cari alasan semakin membuat kamu tidak maju, biasanya hal ini di lakuin untuk menutupi kelemahannya atau sebagai penolakan atas tanggung jawab yg di berikannya. kamu juga bakal kehilangan kepercayaan dari orang orang terdekat kamu akibat selalu mencari cari alasan.

CARI JALAN, BUKAN ALASAN

orang sukses itu mereka yg senantiasa mencari jalan supaya tujuan mereka menjadi kenyataan, bukan dengan mencari cari alasan, mengeluh atau menyalahkan orang.
