---
description: "Apa yang kamu miliki? Apa yang benar-benar kamu kuasai? Apa yang kamu nikmati?"
date: "2021-12-04T00:00:00.000Z"
featured_image: "https://i.ibb.co/xX3gBws/pexels-mikael-blomkvist-6476595-1.jpg"
title: "Dilema freelancer"
author: "Saya"
---

Berpartisipasi di pasar membutuhkan keterampilan bagi mereka yang memiliki [pilihan](https://fajarr.space/tentukan-pilihan "pilihan"), memutuskan apa yang akan ditawarkan kepada pelanggan adalah pilihan kamu

Jika kamu memiliki relasi, kamu dapat menciptakan nilai lebih dari setiap kali memulai pekerjaan baru

Jika kamu benar-benar ahli dalam sesuatu dan memiliki keterampilan, kemungkinan besar kamu akan menciptakan sesuatu dengan lebih mudah

Jika kamu fokus pada pekerjaan yang benar-benar di sukai, hidup kamu akan lebih baik dan akan lebih mudah untuk menyelesaikan pekerjaan

Freelance itu bukan sekadar mencari info lowongan kerja, lalu menawarkan jasa, dikerjakan sesuai pesanan, kemudian mendapat bayaran, tapi bagaimana kita membentuk karakter yang profesional yang mampu menyelesaikan tanggung jawab secara mandiri

Apa yang kamu miliki?

Apa yang benar-benar kamu kuasai?

Apa yang kamu nikmati?
