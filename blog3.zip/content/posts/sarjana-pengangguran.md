---
title: Sarjana pengangguran
date: "2020-05-16T00:00:00.000Z"
description:
  Dunia kerja membutuhkan skill kamu, gelar saja tidak cukup untuk menggambarkan
  apa yg kamu punya.
featured_image: https://i.ibb.co/YpghzXx/graduation-cap-3430714-640.jpg
author: Saya
---

Dunia kerja membutuhkan skill kamu, gelar saja tidak cukup untuk menggambarkan apa yg kamu punya.
