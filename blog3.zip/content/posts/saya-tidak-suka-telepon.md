---
description: "Telepon atau bertemu langsung. Tidak ada waktu untuk berpikir dengan matang"
date: "2022-03-27T00:00:00.000Z"
featured_image: "https://i.ibb.co/x2KxgPw/pexels-min-an-1006122.jpg"
title: "Saya tidak suka telepon"
author: "Saya"
---

Tidak ada waktu untuk berpikir dengan matang,

Saat orang ingin meminta tolong, kita jadi sering tidak enak untuk menolak, akhirnya di"IYA"kan,

Atau saat ingin bertanya, kita jadi asal jawab, yang belum tentu tepat dengan kondisinya,

Dengan berkomunikasi “async” (tidak langsung). Kita memberi jeda diri sendiri dan dirinya untuk berpikir.
