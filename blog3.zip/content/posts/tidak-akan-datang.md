---
title: Tidak akan datang
date: "2020-02-03T00:00:00.000Z"
featured_image: https://i.ibb.co/jgHNxQM/businessman-336621-640.jpg
description:
  Doni & teman2 akan bermain futsal esok hari dan akan menjadi hari yg
  menyenangkan khusus bagi doni, karena di pertandingan sebelum nya ia mencetak banyak
  sekali gol,
author: "Saya"
---

Doni & teman2 akan bermain futsal esok hari dan akan menjadi hari yg menyenangkan khusus bagi doni, karena di pertandingan sebelum nya ia mencetak banyak sekali gol, lalu doni pun sedang melamun, ia sedang memikirkan dirinya menjadi superstar di lapangan futsal karena mencetak banyak gol, dan saking halu nya dia menggambarkan visual wanita sedang menyemangatinya, dan doni berharap hal yang ia pikirkan akan terjadi. esok hari pun telah tiba, doni lantas langsung bergegas menuju lapangan futsal, lalu apa yg terjadi? dari 10 teman doni hanya 5 orang yg hadir, doni pun merasa kecewa, akhirnya dia bermain dengan 5 orang saja, doni tidak pernah mengharapkan hal ini terjadi, bertolak belakang dengan apa yang dipikirkan kemarin, bahkan tidak ada wanita satupun di lapangan tersebut.

kadang alur kehidupan itu unik, ketika apa yg kita rencanakan tidak sesuai dengan kenyataan, dan kamu akan merasa kecewa.

### Overthinker

orang yg selalu berfikir berlebihan,cenderung menebak-nebak keputusan yg mereka buat atau membayangkan hal buruk akan datang setiap saat.
Berpikir berlebih juga cenderung mencegah manusia untuk menyelesaikan sebuah permasalahan dan terkadang memunculkan malapetaka bagi suasana hati. Rasa khawatir akan menggiring seseorang kepada hal-hal negatif tentang masa depan atau apa yang akan terjadi nanti, atau sebaliknya.

Tidak usah pusing memikirkan apa yang akan terjadi besok dan menyesali yang sudah terjadi kemarin. Kalau pikiran kamu hanya fokus pada apa yang terjadi kemarin dan besok, hari ini tidak akan kita lalui dengan maksimal. Padahal, kalau saja Anda berbuat total untuk hari ini, banyak hal menyenangkan yang mungkin saja terjadi.

jadi berhentilah memikirkan hal yg berlebihan. berpikirlah untuk hari ini, saat ini, dan detik ini, pikirkan apa yg akan kamu lakukan untuk hari ini, buatlah planning yg tepat di masa depan & jangan memikirkan hal yg tidak perlu/yg mustahil kamu dapatkan (tanpa usaha) Malah terkadang apa yg tidak kita pikirkan akan lebih menyenangkan dibanding apa yg selalu kita pikirkan

> “Bahwa hidup ini penuh misteri dan tidak sesederhana yang kamu bayangkan. Perbuatan terkadang tidak selalu cukup untuk mewakili perasaan, dalam beberapa hal kamu harus mengatakannya.”

> ― windhy puspitadewi
