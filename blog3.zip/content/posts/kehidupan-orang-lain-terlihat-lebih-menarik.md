---
description: "Merasa orang lain punya jalan instan, padahal sama susahnya"
date: "2021-10-09T00:00:00.000Z"
featured_image: "https://i.ibb.co/d0yBqBM/old-woman-731423-640.jpg"
title: "Pengen jadi orang lain"
author: "Saya"
---

Mau menjadi “dia”, Berusaha seperti dia, Padahal Tuhan sengaja Menciptakan kita berbeda

"pengen" deh kayak dia. Basa-basi dalam hati ketika kita cemburu dengan orang yang jauh lebih menarik dibanding kita

Mau lari dari proses yang sudah lama diperjuangkan, Merasa orang lain punya jalan instan, padahal sama susahnya

Hanyut dalam perlombaan menjadi dia, Padahal ada tempat spesial untuk kita

Setiap dari kita punya peran masing-masing, yang kita adalah pelaku terbaiknya

Semoga menjadi penyemangat, Untuk kamu yang hampir menyerah
