---
description: "Jangan Hanya . . ."
date: "2022-01-15T00:00:00.000Z"
featured_image: "https://i.ibb.co/yPKVT7q/pexels-kat-smith-551576-1.jpg"
title: "Hidup dengan Think to be Thing"
author: "Saya"
---

Jangan Hanya . . .

Don't just learn, experience  
Don't just read, absorb  
Don't just change, transform  
Don't just relate, advocate  
Don't just promise, prove  
Don't just criticize, encourage  
Don't just think, ponder  
Don't just take, give  
Don't just see, feel  
Don’t just dream, do  
Don't just hear, listen  
Don't just talk, act  
Don't just tell, show  
Don't just exist, live

![](https://i.ibb.co/yPKVT7q/pexels-kat-smith-551576-1.jpg)

Photo by [**Kat Smith**](https://www.pexels.com/@katlovessteve?utm_content=attributionCopyText&utm_medium=referral&utm_source=pexels) from [**Pexels**](https://www.pexels.com/photo/boy-standing-near-fence-pointing-on-the-sky-551576/?utm_content=attributionCopyText&utm_medium=referral&utm_source=pexels)
