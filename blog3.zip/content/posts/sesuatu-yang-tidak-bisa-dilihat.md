---
description: "Seringkali, begitu kita belajar melihat, kita berasumsi bahwa kita selalu tahu"
date: "2022-03-26T00:00:00.000Z"
featured_image: "https://i.ibb.co/mFxdSYG/pexels-karolina-grabowska-4468154.jpg"
title: "Sesuatu yang tidak bisa dilihat"
author: "Saya"
---

Seringkali, begitu kita belajar melihat, kita berasumsi bahwa kita selalu tahu. Dan itu memungkinkan kita untuk percaya bahwa hal-hal yang tidak dapat kita lihat, tidak akan pernah bisa kita lihat.

Tapi nggak seperti itu kecuali kita berpuas diri,

Selalu ada sesuatu, yang kebanyakan orang nggak sadar. Tapi kita bisa jika kita memilih.
