---
title: Puas dengan hasil instan
date: "2020-11-05T00:00:00.000Z"
description: terdengar puas ketika menyelesaikan pekerjaan dengan mudah, dan puas juga rasanya mengarapkan hasil tanpa usaha / hasil instan
featured_image: https://i.ibb.co/h8fN3dV/rasa-instan.png
author: Saya
---

Cinta dengan pekerjaanmu? atau tidak? hmm ini bukan soal suka atau tidak suka ya, melainkan dengan cara apa kita bisa menyelesaikan sesuatu yang kita kerjakan.

Pekerjaan juga akan lebih menyenangkan jika dilakukan dengan cara yang kita sukai, apalagi dengan cara yang instan, dan itu normal. hmm kaya nya kurang tepat deh disebut 'menyenangkan', kalo kita melakukan nya secara instan ada kemungkinan kita tidak menyukai pekerjaan tersebut / sedang terburu buru ingin mengerjakan yang lain dann atau juga kita sedang MALAS untuk melakukan sesuatu dan mengharapkan hasil yang instan.

![](https://i.ibb.co/b3CWgjd/instan-min.jpg)

terdengar puas ketika menyelesaikan pekerjaan dengan mudah, dan puas juga rasanya mengarapkan hasil tanpa usaha / hasil instan, rasa nya tidak mudah melakukan sesuatu yang besar bagi yang ingin rasa puas dengan hasil instan dan saya juga pernah merasakan itu. nikmati setiap proses nya, dari situ kita banyak belajar kekurangan pada diri kita dan apa yang harus kita lakukan untuk menutupi semua itu, semua ada prosesnya, mustahil kita dapat apa yang kita inginkan dengan hanya berkata 'saya harus ini, saya harus masuk sini' tanpa melibatkan sebuah proses, dan proses itulah nanti yang menentukan hasil.

kita hidup di zaman yang serba instan, apapun yang kita mau semua sudah tersedia, tak perlu repot mencari makanan, barang, atau memesan tiket. teknologi nyatanya bukan satu-satunya penyebab berkembangnya budaya instan. Kemajuan zaman dalam hal perbaikan ekonomi, politik dan sosial juga mendorong budaya instan berkembang pesat.

budaya instan membuat banyak orang melupakan esensi dari proses. orang-orang dipaksa menerima kenyataan bahwa dunia ini baik-baik saja. segala kecepatan, kenyamanan, dan asyiknya hidup dalam kemudahan.
