---
description: "Kamu mungkin tidak mendapatkannya, Tapi.."
date: "2022-03-03T00:00:00.000Z"
featured_image: "https://i.ibb.co/7CL4Xbr/pexels-andrea-piacquadio-3756042.jpg"
title: "Keinginan kita mengubah kita"
author: "Saya"
---

Kamu mungkin tidak mendapatkannya

Tapi..

Saat Kamu mengejar keinginan ini, Kamu akan mengubah apa yang Kamu lakukan, apa yang Kamu lihat, dengan siapa Kamu terhubung, dan pengorbanan yang Kamu lakukan di sepanjang waktu.
