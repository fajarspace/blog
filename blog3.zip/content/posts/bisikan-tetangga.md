---
description: "Sebagian orang mungkin akan merasa kesal akibat bisikan tetangga yg menghantui"
date: "2020-10-29T00:00:00.000Z"
featured_image: "https://i.ibb.co/mz6Sj7k/lady-3974502-640.jpg"
title: "Bisikan tetangga"
author: "Saya"
---

Sebagian orang mungkin akan merasa kesal akibat bisikan tetangga yg menghantui, Dan mungkin kita akan merasa down / gak pede dalam berbagai hal akibat bisikan itu,  
.  
Hiraukan apa yg membuat kamu merasa tertekan, daripada dipikirin mending fokus pada tujuan agar lebih bisa melangkah kedepan.
