---
title: "Menulis"
date: "2019-03-17T00:00:00.000Z"
featured_image: "https://i.ibb.co/ySBfkJs/menulis.jpg"
description: "tulis apa yang harus ditulis"
author: "Saya"
---

Menulis✏️

hai, saya fajar, dan ini kali pertaman saya menulis di blog.
