---
title: Jadi sapi warna ungu
date: "2020-06-02T00:00:00.000Z"
description:
  pernah ga kamu jalan-jalan ke peternakan, disana kita bisa lihat sapi
  bewarna coklat, atau putih hitam, atau sejenisnya. Bayangkan jika kita menemukan
  sapi warna ungu, hmm ada ga ya?
featured_image: https://i.ibb.co/bXBmXrb/purple-3567972-640.jpg
author: Saya
---

pernah ga kamu jalan-jalan ke peternakan, disana kita bisa lihat sapi bewarna coklat, atau putih hitam, atau sejenisnya. Bayangkan jika kita menemukan sapi warna ungu, hmm ada ga ya? Rata-rata sapi warna nya kan hitam-putih, Kalau ada mungkin kita langsung kaget, foto foto selfie dan langsung cerita ke orang lain,

sekarang coba bayangkan diri kamu menjadi seperti sapi ungu, kamu akan menjadi pusat perhatian, semua orang akan fokus melihat kamu, mengapa? karna sapi tsb memiliki warna yg tidak biasa dan berbeda dengan yg lainnya.

apa maksud nya? makna yg kita ambil adalah kita harus menjadi orang yang berbeda dalam artian positif, minoritas tapi berkualitas, daripada mayoritas tapi biasa biasa saja. orang cenderung akan melihat dan memperhatikan sesuatu yg baru, sesuatu yg biasa2 saja akan mudah terlupakan, dan luput dari perhatian

temen2 bisa membaca buku purple cow karya seth godin, buku tentang Marketing yang ditulis oleh Seth Godin pada tahun 2002. Buku ini berisi tentang bagaimana caranya bisa menghasilkan produk-produk berkualitas serta memiliki nilai jual tinggi.

pada buku tersebut Seth Godin sedang berjalan-jalan di sebuah peternakan dengan banyak gerombolan sapi yang sedang memakan rumput. Beberapa saat lamanya, Seth Godin sangat menikmati pemandangan yang indah di sebuah peternakan dengan sapi-sapi yang bergerombol. Namun lama-kelamaan Seth Godin merasa jenuh dengan pemandangan sapi yang biasa-biasa saja. Ia berpikir jika ada satu buah sapi berwarna ungu diantara gerombolan sapi tersebut, maka akan terlihat lebih indah pemandangannya karena terlihat unik dan menarik dan mencolok bedanya dengan yang lain.

perbedaan adalah sesuatu yang biasa dan baik, kebanyakan dari kita berfikir untuk berusaha menjadi seperti orang lain, padahal tuhan sengaja menciptakan kita berbeda, karena sesuatu yg berbeda itu mudah dikenali orang lain.

nih coba banyangin, orang yg jualan bakso ada banyak. yg jualan mie ayam juga banyak. Bagaimana caranya dari sekian banyak saingan yang berjualan bakso dan mie ayam seperti contoh tadi? maka dari itu mengapa penting menjadi beda. Kalau katanya Seth Godin, Pakar Marketing Dunia, beliau bilang jadilah sapi ungu.

Disaat sapi yang lain warnanya putih, coklat, atau hitam seperti warna sapi yang kita tau, di sini kamu harus jadi sapi yang warnanya ungu. Disaat orang lain jualan bakso isinya telur ayam, kamu jualan bakso isinya telur asin. Jadilah beda, jadilah unik, dilirik karena menarik

Seperti yang dikatakan oleh godin, jika dalam perkumpulan sapi semuanya berwana putih belang-belang hitam, dan kamu menjadi sapi ungu di kumpulan sapi tersebut ,maka kamu akan dilirik karena kamu berbeda dan mencolok. Begitu juga dengan usaha atau bisnis. misalnya kamu bekerja di perusahaan, Pekerja lain terlihat biasa2 saja, maka kamu harus ramah supaya atasan kamu melirik kamu karena perbedaan mu dari yang lain.

kamu tau Komputer Apple? siapa sih yg gatau komputer besutan apple ini, Komputer Apple memasuki bisnis komputer paling belakangan, dan hanya dengan modal kecil, mampu memenangkan persaingan melawan raksasa seperti IBM, dengan tidak menantang langsung. Maka Apple muncul dengan menampilkan desain yang unik dan menarik dan menyatakan ini adalah komputer baru yang benar-benar berbeda dari yang ada. Komputer pribadi yang ramah dengan pemakainya. Dan mungkin kita semua tahu kisah selanjutnya, Apple bahkan terus melaju, bukan hanya dengan produk komputer, tetapi juga iPod, iPad, dan iPhone yang masih mengandalkan desain menarik dan sangat ramah dengan pemakainya.
bukan main tuh, target bisnis nya apple aja sekelas perusahaan besar / orang2 kelas menengah ke atas

seperti hal nya elang yang terbang bebas di langit. Menjadi yang berbeda memang tak semudah menaikan resleting celana. Kita akan menghadapi begitu banyak kerikil tajam bahkan duri.

Ketika yang lain menghabiskan seluruh waktunya untuk bersenang-senang, anda dengan giat membangun suatu peluang usaha. Ketika yang lain tidur pulas, anda masih tetap buka mata untuk bekerja keras.

Orang-orang yang kebanyakan berhasil adalah orang yang memiliki penglihatan yang berbeda dibanding yang lain. ya walaupun saya juga blm jadi yg berhasil haha, Hanya saja bagaimana kita bisa berbeda dari yg lain
