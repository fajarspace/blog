---
description: "Alih-alih 'ini' atau 'itu', jawabannya mungkin 'keduanya'"
date: "2021-08-20T00:00:00.000Z"
draft: false
featured_image: "https://i.ibb.co/sHg9XBZ/pexels-andres-ayrton-6551415.jpg"
title: "Asumsikan keduanya benar"
author: "Saya"
---

Alih-alih 'ini' atau 'itu', jawabannya mungkin 'keduanya'

Terkadang, kita sangat ingin melawan ide baru (untuk melindungi ide lama) sehingga kita kehilangan kesempatan untuk membayangkan bagaimana kita bisa maju

Jauh lebih mudah untuk bersikap tegas. Itu juga tidak terlalu produktif, mungkin untuk mendukung sesuatu tanpa menentang sesuatu yang lain.
