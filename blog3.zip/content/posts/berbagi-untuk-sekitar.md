---
description: "Berbagi bahagia di Bulan Ramadhan 1442 H melalui program Mari Berbagi"
date: "2021-07-08T00:00:00.000Z"
featured_image: "https://i.ibb.co/BqZH8p2/272447.jpg"
title: "Berbagi untuk sekitar"
author: "Saya"
---

Berbagi bahagia di Bulan Ramadhan 1442 H melalui program **Mari Berbagi**. Dimana ini merupakan program berbagi paket makanan berupa tajil dan menu lengkap untuk berbuka. **Mari berbagi** didistribusikan ke wilayah sekitar jababeka & cikarang dengan penerima manfaat yang terdiri dari fakir, miskin, serta masyarakat yang membutuhkan secara umum.

![](https://i.ibb.co/Sw7WCDj/berbagi.jpg)

Lihat laporan keuangan [disini](https://1drv.ms/x/s!Amx47EgxcZbqhwJcfgoYvwLpodKd?e=f8qMAg)
