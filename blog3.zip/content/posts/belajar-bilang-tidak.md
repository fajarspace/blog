---
description: >-
  Penyakit mental terbesar saya selalu merasa gak enakan sama orang, ternyata
  dampak nya cukup besar ketika saya meng'iya'kan sesuatu.
date: "2021-06-20T00:00:00.000Z"
featured_image: "https://i.ibb.co/r2q5W9x/noo-min.jpg"
title: Berani bilang tidak
author: Saya
---

Penyakit mental terbesar saya selalu merasa gak enakan sama orang, ternyata dampak nya cukup besar ketika saya meng'iya'kan sesuatu.

👨‍🔧 : "jar, kamu mau ngga narikin duit wifi tiap bulannya, lumayan uang jajan ada"

(dalem hati saya merasa ngga mampu)

🙅‍♂️ saya: "oh iya bisa bisa"

👨‍🔧 : "oke siap"

orang itu udah mempercayakan saya untuk hal yg di sampaikan di atas, karena saya merasa tidak enak untuk menolak maka saya terima. lalu gimana cara saya untuk menolaknya?

setelah beberapa hari saya bertemu kembali dengan orang tersebut, menjelaskan mengapa tidak bisa dan akhirnya saya lebih harus hati-hati lagi dalam [membuat keputusan](https://fajarr.space/tentukan-pilihan).

![](https://i.ibb.co/4thjYnX/say-no-min.jpg)

"Tidak" hanya kata yang kecil, tetapi memiliki dampak yang besar. Itulah mengapa, banyak orang tidak nyaman dan tidak mampu mengatakannya

Di sisi lain, ada beberapa orang yang dapat dengan mudah mengatakan 'tidak' untuk hal-hal yang tidak ingin mereka lakukan. Mereka tidak [ragu-ragu](https://fajarr.space/ragu) dan tidak merasa bersalah dalam melakukannya. yaa mungkin karena mereka memiliki sikap pemimpin yang bertolak belakang dengan saya 😥

Belajar mengatakan 'tidak' penting untuk hal dan keputusan yang memberatkan dan membuat stres. Ini adalah keputusan dan kebiasaan yang harus di bentuk untuk kebaikan diri sendiri tanpa merasa egois. Ini semua tentang menghormati prioritas dan waktu
