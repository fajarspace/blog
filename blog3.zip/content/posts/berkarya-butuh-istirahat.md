---
description: "Kasihan sekali kamu, kasihan sekali karyamu, Kamu menyiksa diri. Jangan dipaksa , Izinkan kamu tumbuh bertahap"
date: "2021-08-07T00:00:00.000Z"
featured_image: "https://i.ibb.co/R4LzjfR/cat-4189697-640.jpg"
title: "Berkarya butuh istirahat"
author: "Saya"
---

Kita ngga akan bisa nyelesaiin [pekerjaan dengan instan](https://fajarr.space/puas-dengan-hasil-instan), kita ngga akan bisa menguasai materi hanya dengan hitungan jam, kita juga ngga bisa mempelajari skill (apapun itu) hanya dengan modal instan. Kita mau karya pertama tampil luar biasa, Butuh ratusan karya gagal, sebelum karya cantik ada

Bikin karya itu gak sama kaya kita bikin mie instan yang semua nya butuh proses yang matang, Bikin karyanya, gambar dulu, tulis dulu, program dulu. Dan ada masanya kita jenuh, gak mood, merasa skill turun. Stop dulu, Istirahat dulu, karena karya yang cantik butuh waktu untuk tumbuh

Kasihan sekali kamu, kasihan sekali karyamu, Kamu menyiksa diri  
Jangan dipaksa , Izinkan kamu tumbuh bertahap
