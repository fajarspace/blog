---
title: Ragu
date: "2020-08-20T00:00:00.000Z"
featured_image: https://i.ibb.co/grpPcPB/pedestrians-400811-640.jpg
Description:
  Kalian pernah gak sih merasa bimbang?  apalagi kalo disuruh milih mau
  jadi apa di masa depan?
---

Kalian pernah gak sih merasa bimbang? apalagi kalo disuruh milih mau jadi apa di masa depan?, masuk kampus mana?, atau bahkan memutuskan perkara sepele sehari-hari. Untuk sekadar menetapkan pilihan dan menetapkan keputusan terkadang emang bisa bikin kepala pusing. Apalagi, keputusan dan pilihan kita itu bakalan berpengaruh untuk masa depan kita.

Bohong jika tak ada manusia yang tak pernah merasa takut atau ragu-ragu. Rasa takut dan rasa ragu terhadap diri sendiri adalah bagian dari emosi dan perasaan setiap manusia. Setiap orang punya rasa takut, sesekali kita pun akan merasa ragu-ragu terhadap diri kita sendiri. Tapi kenapa ada orang yang sukses dan bahagia sementara yang lain malah terus gagal dan menderita?

Seringkali menetapkan suatu keputusan dan pertimbangan yang kurang matang berakhir dengan kata 'penyesalan', dan menuai kata 'keraguan' dari diri sendiri. Situasi yang menjadi momok bagi banyak orang.

Salah satu jawabannya adalah cara kita sendiri untuk menghadapi dan mengatasi rasa takut dan keraguan diri sendiri.

Kita pernah gagal. Kita pernah kecewa. Menyesal. Sedih. Dan merasa jadi orang yang paling sial. Banyak hal yang bisa membuat kita merasa takut dan malah ragu terhadap diri sendiri. Apakah ini sesuatu yang normal? Tentu saja, sangat normal. Tapi Anda harus bisa melakukan sesuatu agar rasa takut dan keraguan terhadap diri sendiri itu tidak malah berbalik untuk menyiksa diri Kita.
