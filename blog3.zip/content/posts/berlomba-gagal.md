---
description: >-
  Kalau kata seth godin “yang paling banyak gagal yang akan menang”. Jangan
  takut gagal atau ditolak, ini cerita biasa.
date: "2021-07-17T17:00:00.000Z"
featured_image: "https://i.ibb.co/BskqVSB/women-801940-640.jpg"
title: Berlomba gagal
author: Saya
---

Novel pertama yang ditulis Stephen King, “Carrie” ditolak puluhan kali sebelum berhasil diterbitkan, Bahkan King pernah merasa sangat jenuh dan membuang draft karyanya ke tempat sampah

Cerita yang sama datang dari JK Rowling, penulis Harry Potter. Untung saja mereka tidak berhenti saat itu. Mereka terus menulis buku, tidak terhitung jumlah orang yang membaca bukunya sekarang

Colonel Sanders, sang pendiri KFC pun pernah merasakan sakitnya kegagalan dalam usaha. wajahnya kini terpampang di berbagai sudut kota sebagai penemu ayam goreng renyah yang banyak disukai orang

Ada berapa banyak musisi yang musiknya tidak diterima label rekaman pertama kali, ada berapa banyak sales marketing yang ditolak. Begitu juga dengan pekerjaan lainnya

Kalau kata seth godin “yang paling banyak gagal yang akan menang”. Jangan takut gagal atau ditolak, ini cerita biasa.
