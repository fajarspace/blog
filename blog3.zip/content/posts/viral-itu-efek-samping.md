---
description: "Ketika menjadi viral di indonesia itu sangat mudah, kebanyakan yang jadi viral itu sesuatu yang tidak bermanfaat, tidak etis, atau banyak merugikan"
date: "2021-12-01T00:00:00.000Z"
featured_image: "https://i.ibb.co/ZKdRpr2/social-media-763731-640.jpg"
title: "Viral itu efek samping"
author: "Saya"
---

Akhir akhir ini saya kaget melihat pemuda yg nekat membuat konten berbahaya, dimana aksinya memberhentikan truk yang sedang melintas di tengah jalan raya hanya demi VIRAL, bisa terbayang bagaimana nasib supir truk nya

Beberapa waktu lalu, salah satu postingan di twitter, yang mengaitkan pegiat sosial media, ia me retweet komentar orang yang mengatakan "diem2 ternyata gay", akhirnya tweet tersebut menjadi ramai

Ketika menjadi viral di indonesia itu sangat mudah, kebanyakan yang jadi viral itu sesuatu yang tidak bermanfaat, tidak etis, atau banyak merugikan penonton untuk usia 5 -12 tahun yang terkena dampak nya

Saya masih penasaran, apakah ada satu orang terkenal yang membagikannya atau memang masalah ini terlalu dirasakan oleh banyak orang di Indonesia sehingga terus dibagikan

Banyak platform digital yang menyediakan ruang untuk viral, sayang sekali kalau di isi dengan hiburan yang bisa merusak generasi

Terbayang, jika suatu saat anak cucu kita melihat rekam jejak kita di media sosial, mereka akan bertanya tanya. Untungnya saya bukan mencari viral, hanya mau terus berkarya sampai ketika VIRAL itu menjadi obat yang tidak ada EFEK SAMPING nya
