---
description: "Banyak yang bilang kalau sesuatu yang besar dimulai dari yang kecil "
date: "2021-06-20T00:00:00.000Z"
featured_image: "https://i.ibb.co/3pM71qT/hal-kecil.jpg"
title: "Hal kecil setiap hari"
author: "Saya"
---

Banyak yang bilang kalau sesuatu yang besar dimulai dari yang kecil dan kenyataan nya memang sudah seperti itu, sederhana nya orang dewasa tidak akan pernah menjadi dewasa tanpa melalui masa kecil, sama hal nya seperti sesuatu yang kita kerjakan terus menerus (konsisten) akan menjadi besar tiap hari nya.

![](https://i.ibb.co/fXNSJVk/berkebun.png)
