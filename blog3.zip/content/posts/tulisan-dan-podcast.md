---
description: "Kenapa menulis? kenapa membuat podcast?"
date: "2021-06-23T00:00:00.000Z"
draft: true
featured_image: "/img/featured-img/mic.jpg"
title: "Tulisan dan podcast"
author: "Saya"
---

Kenapa saya [menulis](https://fajarr.space/tulisan)? kenapa saya membuat [podcast](https://selembarkertas.netlify.app)? setelah lulus sekolah saya bingung ingin buat apa, mencoba mengisi kekosongan dengan belajar hal yang saya suka, lalu rasa jenuh datang menghantui

singkat cerita, saya melihat sebuah website [hilman ramadhan](https://hilman.space), blog yang isinya penuh dengan tulisan dan podcast [tehataukopi](https://anchor.fm/tehataukopi), mulai dari situ saya tertarik ingin membuat website seperti mas hilman ini.

![](/uploads/screen-shot-2021-06-24-at-21-58-24.png)

Oh iya sebelum nya terimakasih mas hilman sudah mengizinkan memakai tempelate website nya 😁 entah kenapa mata saya merasa nyaman lihat desain yang simpel - simpel
