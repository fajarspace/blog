exports.id = 947;
exports.ids = [947];
exports.modules = {

/***/ 6004:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ App)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _static_styles_globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3043);
/* harmony import */ var _static_styles_globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_static_styles_globals_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _theme_config__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6525);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_3__);




function App({ Component, pageProps }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_3___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "robots",
                        content: "follow, index"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "description",
                        content: _theme_config__WEBPACK_IMPORTED_MODULE_2__/* .metadata */ .Pu.description
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:site_name",
                        content: _theme_config__WEBPACK_IMPORTED_MODULE_2__/* .metadata */ .Pu.url
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:description",
                        content: _theme_config__WEBPACK_IMPORTED_MODULE_2__/* .metadata */ .Pu.description
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:title",
                        content: _theme_config__WEBPACK_IMPORTED_MODULE_2__/* .metadata */ .Pu.title
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "twitter:card",
                        content: _theme_config__WEBPACK_IMPORTED_MODULE_2__/* .metadata */ .Pu.image
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "twitter:site",
                        content: _theme_config__WEBPACK_IMPORTED_MODULE_2__/* .metadata */ .Pu.twitter_site
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "twitter:title",
                        content: _theme_config__WEBPACK_IMPORTED_MODULE_2__/* .metadata */ .Pu.title
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "twitter:description",
                        content: _theme_config__WEBPACK_IMPORTED_MODULE_2__/* .metadata */ .Pu.description
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "twitter:image",
                        content: _theme_config__WEBPACK_IMPORTED_MODULE_2__/* .metadata */ .Pu.image
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "shortcut icon",
                        href: _theme_config__WEBPACK_IMPORTED_MODULE_2__/* .metadata */ .Pu.favicon,
                        type: "image/x-icon"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "manifest",
                        href: "/manifest.json"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: _theme_config__WEBPACK_IMPORTED_MODULE_2__/* .metadata */ .Pu.title
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                ...pageProps
            })
        ]
    });
}


/***/ }),

/***/ 6088:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Document)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var next_document__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6859);
/* harmony import */ var next_document__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_document__WEBPACK_IMPORTED_MODULE_1__);


function Document() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(next_document__WEBPACK_IMPORTED_MODULE_1__.Html, {
        lang: "en",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_document__WEBPACK_IMPORTED_MODULE_1__.Head, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("body", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_document__WEBPACK_IMPORTED_MODULE_1__.Main, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_document__WEBPACK_IMPORTED_MODULE_1__.NextScript, {})
                ]
            })
        ]
    });
}


/***/ }),

/***/ 6525:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Pu: () => (/* binding */ metadata),
/* harmony export */   kQ: () => (/* binding */ content),
/* harmony export */   wx: () => (/* binding */ components)
/* harmony export */ });
// theme.config.js
const metadata = {
    title: "Fajar A",
    favicon: "./static/images/favicon.ico",
    description: "Temukan Tulisan / baca blog dev, kamu juga bisa mendengarkan Podcast",
    image: "https://i.ibb.co/DCwqZCM/typewriter.jpg",
    url: "https://fajarr.space",
    twitter_site: "@fajaragngn"
};
const content = {
    title: "halo \uD83D\uDC4B",
    intro: `Saya Fajar Agung. Suka ngoding yang gak jelas, Sedikit bicara banyak
    mikir (bukan aksi).`
};
const components = [
    {
        type: "navbar",
        title: "About",
        url: "/"
    },
    {
        type: "navbar",
        title: "Photos",
        url: "/photos"
    },
    {
        type: "navbar",
        title: "Posts",
        url: "/posts"
    },
    {
        type: "footer",
        name: "\xa9 stuff-blog",
        year: new Date().getFullYear()
    },
    {
        type: "footer",
        social: "GitHub",
        url: "https://github.com/fajarspace"
    },
    {
        type: "footer",
        social: "Instagram",
        url: "https://instagram.com/fajar.agngn"
    }
];


/***/ }),

/***/ 3043:
/***/ (() => {



/***/ })

};
;