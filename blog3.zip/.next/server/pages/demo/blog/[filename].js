"use strict";
(() => {
var exports = {};
exports.id = 718;
exports.ids = [718];
exports.modules = {

/***/ 2502:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   config: () => (/* binding */ config),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   getServerSideProps: () => (/* binding */ getServerSideProps),
/* harmony export */   getStaticPaths: () => (/* binding */ getStaticPaths),
/* harmony export */   getStaticProps: () => (/* binding */ getStaticProps),
/* harmony export */   reportWebVitals: () => (/* binding */ reportWebVitals),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   unstable_getServerProps: () => (/* binding */ unstable_getServerProps),
/* harmony export */   unstable_getServerSideProps: () => (/* binding */ unstable_getServerSideProps),
/* harmony export */   unstable_getStaticParams: () => (/* binding */ unstable_getStaticParams),
/* harmony export */   unstable_getStaticPaths: () => (/* binding */ unstable_getStaticPaths),
/* harmony export */   unstable_getStaticProps: () => (/* binding */ unstable_getStaticProps)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3185);
/* harmony import */ var next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5244);
/* harmony import */ var next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7182);
/* harmony import */ var private_next_pages_document_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6088);
/* harmony import */ var private_next_pages_app_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6004);
/* harmony import */ var private_next_pages_demo_blog_filename_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4829);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([private_next_pages_demo_blog_filename_js__WEBPACK_IMPORTED_MODULE_5__]);
private_next_pages_demo_blog_filename_js__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
// @ts-ignore this need to be imported from next/dist to be external



// Import the app and document modules.
// @ts-expect-error - replaced by webpack/turbopack loader

// @ts-expect-error - replaced by webpack/turbopack loader

// Import the userland code.
// @ts-expect-error - replaced by webpack/turbopack loader

const PagesRouteModule = next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__.PagesRouteModule;
// Re-export the component (should be the default export).
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_demo_blog_filename_js__WEBPACK_IMPORTED_MODULE_5__, "default"));
// Re-export methods.
const getStaticProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_demo_blog_filename_js__WEBPACK_IMPORTED_MODULE_5__, "getStaticProps");
const getStaticPaths = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_demo_blog_filename_js__WEBPACK_IMPORTED_MODULE_5__, "getStaticPaths");
const getServerSideProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_demo_blog_filename_js__WEBPACK_IMPORTED_MODULE_5__, "getServerSideProps");
const config = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_demo_blog_filename_js__WEBPACK_IMPORTED_MODULE_5__, "config");
const reportWebVitals = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_demo_blog_filename_js__WEBPACK_IMPORTED_MODULE_5__, "reportWebVitals");
// Re-export legacy methods.
const unstable_getStaticProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_demo_blog_filename_js__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticProps");
const unstable_getStaticPaths = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_demo_blog_filename_js__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticPaths");
const unstable_getStaticParams = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_demo_blog_filename_js__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticParams");
const unstable_getServerProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_demo_blog_filename_js__WEBPACK_IMPORTED_MODULE_5__, "unstable_getServerProps");
const unstable_getServerSideProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_demo_blog_filename_js__WEBPACK_IMPORTED_MODULE_5__, "unstable_getServerSideProps");
// Create and export the route module that will be consumed.
const routeModule = new PagesRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__/* .RouteKind */ .x.PAGES,
        page: "/demo/blog/[filename]",
        pathname: "/demo/blog/[filename]",
        // The following aren't used in production.
        bundlePath: "",
        filename: ""
    },
    components: {
        App: private_next_pages_app_js__WEBPACK_IMPORTED_MODULE_4__["default"],
        Document: private_next_pages_document_js__WEBPACK_IMPORTED_MODULE_3__["default"]
    },
    userland: private_next_pages_demo_blog_filename_js__WEBPACK_IMPORTED_MODULE_5__
});

//# sourceMappingURL=pages.js.map
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4829:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   getStaticPaths: () => (/* binding */ getStaticPaths),
/* harmony export */   getStaticProps: () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var tinacms_dist_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3081);
/* harmony import */ var tinacms_dist_rich_text__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3273);
/* harmony import */ var _tina_generated_client__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8439);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([tinacms_dist_react__WEBPACK_IMPORTED_MODULE_2__, tinacms_dist_rich_text__WEBPACK_IMPORTED_MODULE_3__, _tina_generated_client__WEBPACK_IMPORTED_MODULE_4__]);
([tinacms_dist_react__WEBPACK_IMPORTED_MODULE_2__, tinacms_dist_rich_text__WEBPACK_IMPORTED_MODULE_3__, _tina_generated_client__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
// THIS FILE HAS BEEN GENERATED WITH THE TINA CLI.
// This is a demo file once you have tina setup feel free to delete this file





const BlogPage = (props)=>{
    const { data } = (0,tinacms_dist_react__WEBPACK_IMPORTED_MODULE_2__.useTina)({
        query: props.query,
        variables: props.variables,
        data: props.data
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                    rel: "stylesheet",
                    href: "https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.7/tailwind.min.css",
                    integrity: "sha512-y6ZMKFUQrn+UUEVoqYe8ApScqbjuhjqzTuwUMEGMDuhS2niI8KA3vhH2LenreqJXQS+iIXVTRL2iaNfJbDNA1Q==",
                    crossOrigin: "anonymous",
                    referrerPolicy: "no-referrer"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        style: {
                            textAlign: "center"
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: "text-3xl m-8 text-center leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl",
                                children: data.post.title
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ContentSection, {
                                content: data.post.body
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "bg-green-100 text-center",
                        children: [
                            "Lost and looking for a place to start?",
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                href: "https://tina.io/guides/tina-cloud/getting-started/overview/",
                                className: "text-blue-500 underline",
                                children: [
                                    " ",
                                    "Check out this guide"
                                ]
                            }),
                            " ",
                            "to see how add TinaCMS to an existing Next.js site."
                        ]
                    })
                ]
            })
        ]
    });
};
const getStaticProps = async ({ params })=>{
    let data = {};
    let query = {};
    let variables = {
        relativePath: `${params.filename}.md`
    };
    try {
        const res = await _tina_generated_client__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z.queries.post(variables);
        query = res.query;
        data = res.data;
        variables = res.variables;
    } catch  {
    // swallow errors related to document creation
    }
    return {
        props: {
            variables: variables,
            data: data,
            query: query
        }
    };
};
const getStaticPaths = async ()=>{
    const postsListData = await _tina_generated_client__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z.queries.postConnection();
    return {
        paths: postsListData.data.postConnection.edges.map((post)=>({
                params: {
                    filename: post.node._sys.filename
                }
            })),
        fallback: false
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BlogPage);
const PageSection = (props)=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                children: props.heading
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                children: props.content
            })
        ]
    });
};
const components = {
    PageSection: PageSection
};
const ContentSection = ({ content })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "relative py-16 bg-white overflow-hidden",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "hidden lg:block lg:absolute lg:inset-y-0 lg:h-full lg:w-full",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "relative h-full text-lg max-w-prose mx-auto",
                    "aria-hidden": "true",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                            className: "absolute top-12 left-full transform translate-x-32",
                            width: 404,
                            height: 384,
                            fill: "none",
                            viewBox: "0 0 404 384",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("defs", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("pattern", {
                                        id: "74b3fd99-0a6f-4271-bef2-e80eeafdf357",
                                        x: 0,
                                        y: 0,
                                        width: 20,
                                        height: 20,
                                        patternUnits: "userSpaceOnUse",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                                            x: 0,
                                            y: 0,
                                            width: 4,
                                            height: 4,
                                            className: "text-gray-200",
                                            fill: "currentColor"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                                    width: 404,
                                    height: 384,
                                    fill: "url(#74b3fd99-0a6f-4271-bef2-e80eeafdf357)"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                            className: "absolute top-1/2 right-full transform -translate-y-1/2 -translate-x-32",
                            width: 404,
                            height: 384,
                            fill: "none",
                            viewBox: "0 0 404 384",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("defs", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("pattern", {
                                        id: "f210dbf6-a58d-4871-961e-36d5016a0f49",
                                        x: 0,
                                        y: 0,
                                        width: 20,
                                        height: 20,
                                        patternUnits: "userSpaceOnUse",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                                            x: 0,
                                            y: 0,
                                            width: 4,
                                            height: 4,
                                            className: "text-gray-200",
                                            fill: "currentColor"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                                    width: 404,
                                    height: 384,
                                    fill: "url(#f210dbf6-a58d-4871-961e-36d5016a0f49)"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                            className: "absolute bottom-12 left-full transform translate-x-32",
                            width: 404,
                            height: 384,
                            fill: "none",
                            viewBox: "0 0 404 384",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("defs", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("pattern", {
                                        id: "d3eb07ae-5182-43e6-857d-35c643af9034",
                                        x: 0,
                                        y: 0,
                                        width: 20,
                                        height: 20,
                                        patternUnits: "userSpaceOnUse",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                                            x: 0,
                                            y: 0,
                                            width: 4,
                                            height: 4,
                                            className: "text-gray-200",
                                            fill: "currentColor"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                                    width: 404,
                                    height: 384,
                                    fill: "url(#d3eb07ae-5182-43e6-857d-35c643af9034)"
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "relative px-4 sm:px-6 lg:px-8",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "text-lg max-w-prose mx-auto",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(tinacms_dist_rich_text__WEBPACK_IMPORTED_MODULE_3__.TinaMarkdown, {
                        components: components,
                        content: content
                    })
                })
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8439:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export client */
/* harmony import */ var tinacms_dist_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5530);
/* harmony import */ var _types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(476);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([tinacms_dist_client__WEBPACK_IMPORTED_MODULE_0__, _types__WEBPACK_IMPORTED_MODULE_1__]);
([tinacms_dist_client__WEBPACK_IMPORTED_MODULE_0__, _types__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


const client = (0,tinacms_dist_client__WEBPACK_IMPORTED_MODULE_0__.createClient)({
    url: "https://content.tinajs.io/1.4/content/cf7e7a3f-8276-4680-abb5-d61f6c5551be/github/master",
    token: "825fb31ba162ed2fd2f55dfba40aa4e97ed9c27b",
    queries: _types__WEBPACK_IMPORTED_MODULE_1__/* .queries */ .o$
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (client);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 476:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   o$: () => (/* binding */ queries)
/* harmony export */ });
/* unused harmony exports gql, PostPartsFragmentDoc, PostDocument, PostConnectionDocument, getSdk, ExperimentalGetTinaClient */
/* harmony import */ var tinacms_dist_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5530);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([tinacms_dist_client__WEBPACK_IMPORTED_MODULE_0__]);
tinacms_dist_client__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
function gql(strings, ...args) {
    let str = "";
    strings.forEach((string, i)=>{
        str += string + (args[i] || "");
    });
    return str;
}
const PostPartsFragmentDoc = gql`
    fragment PostParts on Post {
  draft
  title
  date
  description
  body
  featured_image
  author
}
    `;
const PostDocument = gql`
    query post($relativePath: String!) {
  post(relativePath: $relativePath) {
    ... on Document {
      _sys {
        filename
        basename
        breadcrumbs
        path
        relativePath
        extension
      }
      id
    }
    ...PostParts
  }
}
    ${PostPartsFragmentDoc}`;
const PostConnectionDocument = gql`
    query postConnection($before: String, $after: String, $first: Float, $last: Float, $sort: String, $filter: PostFilter) {
  postConnection(
    before: $before
    after: $after
    first: $first
    last: $last
    sort: $sort
    filter: $filter
  ) {
    pageInfo {
      hasPreviousPage
      hasNextPage
      startCursor
      endCursor
    }
    totalCount
    edges {
      cursor
      node {
        ... on Document {
          _sys {
            filename
            basename
            breadcrumbs
            path
            relativePath
            extension
          }
          id
        }
        ...PostParts
      }
    }
  }
}
    ${PostPartsFragmentDoc}`;
function getSdk(requester) {
    return {
        post (variables, options) {
            return requester(PostDocument, variables, options);
        },
        postConnection (variables, options) {
            return requester(PostConnectionDocument, variables, options);
        }
    };
}

const generateRequester = (client, options)=>{
    const requester = async (doc, vars, options2)=>{
        let url = client.apiUrl;
        if (options2?.branch) {
            const index = client.apiUrl.lastIndexOf("/");
            url = client.apiUrl.substring(0, index + 1) + options2.branch;
        }
        const data = await client.request({
            query: doc,
            variables: vars,
            url
        });
        return {
            data: data?.data,
            query: doc,
            variables: vars || {}
        };
    };
    return requester;
};
const ExperimentalGetTinaClient = ()=>getSdk(generateRequester(createClient({
        url: "https://content.tinajs.io/1.4/content/cf7e7a3f-8276-4680-abb5-d61f6c5551be/github/master",
        queries
    })));
const queries = (client, options)=>{
    const requester = generateRequester(client, options);
    return getSdk(requester);
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3076:
/***/ ((module) => {

module.exports = require("next/dist/server/future/route-modules/route-module.js");

/***/ }),

/***/ 4140:
/***/ ((module) => {

module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 9716:
/***/ ((module) => {

module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 3100:
/***/ ((module) => {

module.exports = require("next/dist/server/render.js");

/***/ }),

/***/ 6368:
/***/ ((module) => {

module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 6724:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 8743:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/html-context.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 5530:
/***/ ((module) => {

module.exports = import("tinacms/dist/client");;

/***/ }),

/***/ 3081:
/***/ ((module) => {

module.exports = import("tinacms/dist/react");;

/***/ }),

/***/ 3273:
/***/ ((module) => {

module.exports = import("tinacms/dist/rich-text");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [769,947], () => (__webpack_exec__(2502)));
module.exports = __webpack_exports__;

})();